# Nachweis UI handoff (for Claude Code)

| File | What |
|---|---|
| `CLAUDE_CODE_PROMPT.md` | The prompt to paste into Claude Code (everything below the line) |
| `UI_STYLE.md` | Binding design spec: tokens, rules, components, navigation, dashboard |
| `reference/ui_concepts_glass.html` | Glass concepts A Frost (default), B Graphite (dark option), C Liquid; open in browser |
| `reference/dashboard_concept.html` | Dashboard structure (3 questions), toggle "Datenquellen anzeigen" |
| `reference/*.png` | Screenshots of variant A and the dashboard |

Setup: this folder lives in `~/Projekte/team-apex2/docs/ui/` (clone of JeetManjrekar/team-apex2). Open Claude Code in `~/Projekte/team-apex2`, paste the prompt.
Hard rule: additive only. No existing file is changed; new UI lives in new files (`css/glass.css`, `js/ui-glass.js`, `js/dashboard.js`), the only exception is appending their include lines to `frontend/index.html`.

What matters most for the site manager (and the jury), in order:
1. Capture in seconds (speak, photo), no forms
2. The right document with evidence, Nachtragsmeldung reaches the Nachtragsmanager the same day
3. Trust: source per field, nothing invented, nothing sent without a click
4. Early warning with a suggested letter
5. One place for everything that needs a decision today
